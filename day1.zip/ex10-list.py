numbers = [3, 5, 2, 40, 3, 2]

num_items = len(numbers)
print(num_items)

first_item = numbers[0]
print(first_item)

second_item = numbers[1]
print(second_item)

numbers.append(10)
print(numbers)

numbers.remove(10)
print(numbers)

p
input()