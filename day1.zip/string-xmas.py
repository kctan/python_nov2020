for i in range(10):
    half = "#" * i
    print ("%10s%-10s" % (half, half))