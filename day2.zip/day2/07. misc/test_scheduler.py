import schedule
import time

def task1():
    print("Doing task1... ...")
    
def task2():
    print("Doing task 2... ...")

schedule.every(1).minutes.do(task1)

schedule.every(7).seconds.do(task2)

#schedule.every(5).hour.do(job)
#schedule.every().day.at("10:30").do(job)
#schedule.every().monday.do(job)
#schedule.every().wednesday.at("13:15").do(job)
#schedule.every().minute.at(":17").do(job)

while True:
    schedule.run_pending()
    time.sleep(1)

'''
from task_download import downloadAMKWeather
from task_email import send_email

schedule.every(5).seconds.do(downloadAMKWeather)
schedule.every(1).minutes.do(download)

'''